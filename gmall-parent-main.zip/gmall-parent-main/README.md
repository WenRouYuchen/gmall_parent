# gmall-parent

> 每个项目只提交 pom文件和src的东西，其他都是垃圾。
> 如何不要垃圾